module.exports.rignTone = [
  {
     "value": 0,
    "name":"Default"

  },
  {
    "value": 1,
    "name":"Aurora.caf"
  },
  {
    "value": 2,
    "name":"Bamboo.caf"
  },
  {
    "value": 3,
    "name":"Chord.caf"
  },
  {
    "value": 4,
    "name":"Circle.caf"
  },
  {
    "value": 5,
    "name":"Complete.caf"
  },
  {
    "value": 6,
    "name":"Hello.caf"
  },
  {
    "value": 7,
    "name":"Input.caf"
  },
  {
    "value": 8,
    "name":"Keys.caf"
  },
  {
    "value": 9,
    "name":"Popcorn.caf"
  },
  {
    "value": 10,
    "name":"Pulse.caf"
  },
  {
    "value": 11,
    "name":"Synth.caf"
  }
];
